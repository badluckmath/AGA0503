A nota desse EP foi 8,8. 

A monitora disse que eu errei na interpola��o, n�o usando o exerc�cio anterior na rotina. 

Boa sorte.
