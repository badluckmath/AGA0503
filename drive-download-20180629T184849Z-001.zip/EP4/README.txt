

Segue a corre��o do EP4. Ficou bom o seu trabalho, todos os gr�ficos foram entregues, e o resultado est� correto.
Apenas faltou um pouco de cuidado com rela��o � apresenta��o dos gr�ficos, pois alguns est�o sem legenda e/ou t�tulos nos eixos.

Sua nota foi 9,5

Atenciosamente,
Alex
