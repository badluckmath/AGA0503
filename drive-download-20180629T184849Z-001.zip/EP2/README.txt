Ol�, amiguinho. 

A nota deste EP foi 10.

Beijos. 